package servlets;

public class Passenger {
	private String p_name;
	private int p_age;
	private String p_gender;

	public Passenger(String p_name, int p_age, String p_gender) {
		super();
		this.p_name = p_name;
		this.p_age = p_age;
		this.p_gender = p_gender;
	}

	public String getP_name() {
		return p_name;
	}

	public void setP_name(String p_name) {
		this.p_name = p_name;
	}

	public int getP_age() {
		return p_age;
	}

	public void setP_age(int p_age) {
		this.p_age = p_age;
	}

	public String getP_gender() {
		return p_gender;
	}

	public void setP_gender(String p_gender) {
		this.p_gender = p_gender;
	}

}
