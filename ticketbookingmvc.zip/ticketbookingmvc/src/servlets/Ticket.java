package servlets;

public class Ticket {
	private int tk_no;
	private int tk_pnrno;
	private String tk_traveldate;
	private String tk_from;
	private String tk_to;
	private String tk_class;
	private double tk_total;
	private int tk_pnrcount;

	public Ticket(int tk_no, int tk_pnrno, String tk_traveldate, String tk_from, String tk_to, String tk_class,
			double tk_total, int tk_pnrcount) {
		super();
		this.tk_no = tk_no;
		this.tk_pnrno = tk_pnrno;
		this.tk_traveldate = tk_traveldate;
		this.tk_from = tk_from;
		this.tk_to = tk_to;
		this.tk_class = tk_class;
		this.tk_total = tk_total;
		this.tk_pnrcount = tk_pnrcount;
	}

	public int getTk_no() {
		return tk_no;
	}

	public void setTk_no(int tk_no) {
		this.tk_no = tk_no;
	}

	public int getTk_pnrno() {
		return tk_pnrno;
	}

	public void setTk_pnrno(int tk_pnrno) {
		this.tk_pnrno = tk_pnrno;
	}

	public String getTk_traveldate() {
		return tk_traveldate;
	}

	public void setTk_traveldate(String tk_traveldate) {
		this.tk_traveldate = tk_traveldate;
	}

	public String getTk_from() {
		return tk_from;
	}

	public void setTk_from(String tk_from) {
		this.tk_from = tk_from;
	}

	public String getTk_to() {
		return tk_to;
	}

	public void setTk_to(String tk_to) {
		this.tk_to = tk_to;
	}

	public String getTk_class() {
		return tk_class;
	}

	public void setTk_class(String tk_class) {
		this.tk_class = tk_class;
	}

	public double getTk_total() {
		return tk_total;
	}

	public void setTk_total(double tk_total) {
		this.tk_total = tk_total;
	}

	public int getTk_pnrcount() {
		return tk_pnrcount;
	}

	public void setTk_pnrcount(int tk_pnrcount) {
		this.tk_pnrcount = tk_pnrcount;
	}

}
