package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/LoginServletAsync")
public class LoginServletAsync extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String uname = request.getParameter("username");
		String pwd = request.getParameter("password");
		System.out.println(uname + " " + pwd);
		PrintWriter pw = response.getWriter();
		response.setContentType("application/json");
		String responseData;
		try {
			Class.forName("org.postgresql.Driver");
			Connection cn = DriverManager.getConnection("jdbc:postgresql://192.168.110.48:5432/plf_training",
					"plf_training_admin", "pff123");
			String query = "select * from usersdata where name = ?";
			PreparedStatement pst = cn.prepareStatement(query);
			pst.setString(1, uname);
			ResultSet rs = pst.executeQuery();
			if (rs.next()) {
				if (rs.getString("password").equals(pwd)) {
					responseData = "{\"status\":\"valid\"}";
				} else {
					responseData = "{\"status\":\"invalidpassword\"}";
				}
			} else {
				responseData = "{\"status\":\"invalidusername\"}";
			}
			pw.print(responseData);

		} catch (SQLException e) {
			System.out.println(e.getMessage());
		} catch (ClassNotFoundException e) {
			System.out.println(e.getMessage());
		}

	}

}
