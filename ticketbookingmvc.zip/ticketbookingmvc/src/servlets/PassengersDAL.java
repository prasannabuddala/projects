package servlets;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class PassengersDAL {
	Connection cn = null;

	public PassengersDAL() {
		try {
			Class.forName("org.postgresql.Driver");
			cn = DriverManager.getConnection("jdbc:postgresql://192.168.110.48:5432/plf_training", "plf_training_admin",
					"pff123");
		} catch (ClassNotFoundException e) {
			System.out.println(e.getMessage());
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
	}

	public boolean insertIntoPassengers(int tk_no, String p_name, int p_age, String p_gender) {
		String query = "insert into passengers_pr values(?,?,?,?)";
		PreparedStatement pst;
		try {
			pst = cn.prepareStatement(query);
			pst.setInt(1, tk_no);
			pst.setString(2, p_name);
			pst.setInt(3, p_age);
			pst.setString(4, p_gender);
			int rowsAffected = pst.executeUpdate();
			return rowsAffected > 0;
		} catch (SQLException e) {
			System.out.println(e.getMessage());
			return false;

		}
	}
}
