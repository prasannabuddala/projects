package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

@WebServlet("/BookingController")
public class BookingController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		String from = req.getParameter("from");
		String to = req.getParameter("to");
		String train = req.getParameter("train");
		String date = req.getParameter("date");
		String classs = req.getParameter("classs");
		String passengersData = req.getParameter("passengers");
		System.out.println(passengersData);

		Gson gson = new Gson();
		Passenger[] passengerObjss = gson.fromJson(passengersData, Passenger[].class);

		List<Passenger> passengerObjs = Arrays.asList(passengerObjss);
		System.out.println(passengerObjs);

		int tk_no = generateRandomNumber();
		double fare = getFareByClass(classs);
		int pcount = passengerObjs.size();

		PassengersDAL p = new PassengersDAL();
		boolean b1 = false;
		boolean b2 = false;
		for (Passenger pass : passengerObjs) {
			b1 = p.insertIntoPassengers(tk_no, pass.getP_name(), pass.getP_age(), pass.getP_gender());
			if (!b1) {
				System.out.println("could not insert into passengers");
				break;
			}
		}
		if (b1)
			System.out.println("inserted into passengers");

		TicketsDAL t = new TicketsDAL();
		b2 = t.insertIntoTickets(tk_no, tk_no, date, from, to, classs, fare * pcount, pcount);
		if (b2)
			System.out.println("inserted into tickets");

		JsonObject jsonResponse = new JsonObject();
		if (b1 && b2) {
			System.out.println("successfully inserted into tables");
			jsonResponse.addProperty("success", true);
			jsonResponse.addProperty("ticketno", tk_no);
			jsonResponse.addProperty("tickettotal", fare * pcount);
			jsonResponse.add("passengers", gson.toJsonTree(passengerObjs));
		} else {
			System.out.println("what went wrong");
			jsonResponse.addProperty("success", false);
		}

		res.setContentType("application/json");

		PrintWriter out = res.getWriter();
		out.print(jsonResponse.toString());
		out.flush();
	}

	private int generateRandomNumber() {
		return (int) (Math.random() * 10000) + 1;
	}

	private double getFareByClass(String classs) {
		double base = 60;
		if (classs.equals("General"))
			base = base * 1;
		else if (classs.equals("secondclass"))
			base = base * 1.8;
		else if (classs.equals("tier-1"))
			base = base * 5;
		else if (classs.equals("tier-2"))
			base = base * 3;
		else if (classs.equals("tier-3")) {
			base = base * 2.1;
		}
		return base;
	}
}
