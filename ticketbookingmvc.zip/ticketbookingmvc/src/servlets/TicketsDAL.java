package servlets;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class TicketsDAL {
	Connection cn = null;

	public TicketsDAL() {
		try {
			Class.forName("org.postgresql.Driver");
			cn = DriverManager.getConnection("jdbc:postgresql://192.168.110.48:5432/plf_training", "plf_training_admin",
					"pff123");
		} catch (ClassNotFoundException e) {
			System.out.println(e.getMessage());
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
	}

	public boolean insertIntoTickets(int tk_no, int tk_pnrno, String tk_traveldate, String tk_from, String tk_to,
			String tk_class, double tk_total, int tk_pnrcount) {
		String query = "insert into tickets_pr values(?,?,?,?,?,?,?,?)";
		PreparedStatement pst;
		try {
			pst = cn.prepareStatement(query);
			pst.setInt(1, tk_no);
			pst.setInt(2, tk_pnrno);
			pst.setString(3, tk_traveldate);
			pst.setString(4, tk_from);
			pst.setString(5, tk_to);
			pst.setString(6, tk_class);
			pst.setDouble(7, tk_total);
			pst.setInt(8, tk_pnrcount);
			int rowsAffected = pst.executeUpdate();
			return rowsAffected > 0;
		} catch (SQLException e) {
			System.out.println(e.getMessage());
			return false;

		}
	}
}
