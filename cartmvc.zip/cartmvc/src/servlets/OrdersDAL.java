package servlets;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class OrdersDAL {
	public boolean insertOrder(int orderId, double totalCost, int customerId) {
		String sql = "INSERT INTO orders_pr(o_id,o_total,cust_id) VALUES (?, ?, ?)";

		try (Connection conn = DriverManager.getConnection("jdbc:postgresql://192.168.110.48:5432/plf_training",
				"plf_training_admin", "pff123"); PreparedStatement pstmt = conn.prepareStatement(sql)) {
			pstmt.setInt(1, orderId);
			pstmt.setDouble(2, totalCost);
			pstmt.setInt(3, customerId);

			int rowsAffected = pstmt.executeUpdate();
			return rowsAffected > 0;
		} catch (SQLException ex) {
			ex.printStackTrace();
			return false;
		}
	}
}
